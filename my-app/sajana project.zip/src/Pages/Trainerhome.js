import React from 'react'

import '../Pages/Trainerhome.css'
import Navbar from '../Components/Navbar'

export default function Trainerhome() {
  return (
    <>
      
           <Navbar/>
          





    </>
  )
}
