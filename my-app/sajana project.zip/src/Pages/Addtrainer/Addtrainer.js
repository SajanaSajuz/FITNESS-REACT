import React, { useEffect, useState } from 'react'
import './Addtrainer.css'
import axios from 'axios'
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
export default function Addtrainer() {
  const [addtrainer, setAddtrainer] = useState({

    Username: '',
    Email: '',
    Password: '',
    TrainerName: '',
    Phone: '',
    Designation: '',
    Address: '',
    Gender: ''
  })
  const inputChange = (event) => {
    const { name, value } = event.target
    setAddtrainer({ ...addtrainer, [name]: value })
  }

const navigate=useNavigate()

  const loginid = localStorage.getItem('Id')
  useEffect(()=>{
    if(loginid==null){
      navigate('/Login')
    }
  })


 const [formError, setFormError]= useState({})
 console.log(formError);
 const validate =(values)=>{
 
  var error= {}


  if (!values.Username) {
    error.Username = "Enter Username" 
}
if (!values.Password) {
    error.Password = "Enter Password" 
}
if (!values.Email) {
  error.Password = "Enter Password" 
}
if (!values.Phone) {
  error.Phone = "Enter Password" 
}
if (!values.Designation) {
  error.Designation = "Enter Password" 
}
if (!values.Gender) {
  error.Gender = "Enter Password" 
}
if (!values.Address) {
  error.Address = "Enter Password" 
}
if (!values.TrainerName) {
  error.TrainerName = "Enter Password" 
}


return error
 }




 













  const submit = (event) => {
    event.preventDefault() //page reload aavathe irikan
    setFormError(validate(addtrainer))
    if (Object.keys(formError).length == 0) { //errors undo ille check aakan,ethra length undennum


      // to connect react and node
      axios.post("http://localhost:5000/trainer", addtrainer).then((response) => {

          console.log(response.data.message);

          toast.success(response.data.message, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "light",
          });



      }).catch((error) => {

          console.log(error);
          toast.error(error.response.data.message, {
              position: "top-center",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "colored",
          });
      })








  }

}

 
  


  






   console.log(addtrainer);
  return (
    <>
      <fieldset>

        <legend><h3>Add Trainer</h3></legend>
        <input type="text" name="Username"  onClick={() => { setFormError({ ...formError, Username: "" }) }} onChange={inputChange} placeholder="Username " />
        <span style={{ color: formError.Username ? "red" : "" }}>{formError.Username}</span>
        <input type="text" name="Email"   onClick={() => { setFormError({ ...formError, Email: "" }) }}onChange={inputChange} placeholder="Email" />
        <span style={{ color: formError.Email ? "red" : "" }}>{formError.Email}</span>
        <input type="text" name="Password" onChange={inputChange}   onClick={() => { setFormError({ ...formError, Password: "" }) }}placeholder="Password" />
        <span style={{ color: formError.Password ? "red" : "" }}>{formError.Password}</span>
        <input type=" text" name="TrainerName" onChange={inputChange}   onClick={() => { setFormError({ ...formError, TrainerName: "" }) }}placeholder=" TrainerName" />
        <span style={{ color: formError.TrainerName ? "red" : "" }}>{formError.TrainerName}</span>
        <input type="text" name="Phone" onChange={inputChange}  onClick={() => { setFormError({ ...formError, Phone: "" }) }} placeholder="Phone" />
        <span style={{ color: formError.Phone ? "red" : "" }}>{formError.Phone}</span>
        <input type="text" name="Designation" onChange={inputChange}  onClick={() => { setFormError({ ...formError, Designation: "" }) }} placeholder="Designation" />
        <span style={{ color: formError.Designation ? "red" : "" }}>{formError.Designation}</span>
        <input type="text" name="Address" onChange={inputChange}   onClick={() => { setFormError({ ...formError, Address: "" }) }}placeholder="Address" />
        <span style={{ color: formError.Address ? "red" : "" }}>{formError.Address}</span>
        <input type="text" name="Gender" onChange={inputChange}   onClick={() => { setFormError({ ...formError, Gender: "" }) }}placeholder="Gender" />
        <span style={{ color: formError.Gender ? "red" : "" }}>{formError.Gender}</span>
        <form action="#">

          <button href="#"><i class="fa fa-facebook"></i>Facebook</button>
          <button href="#"><i class="fa fa-google-plus"></i>Google +</button>
          <button href="#"><i class="fa fa-twitter"></i>Twitter</button>
        </form>
        <input type="submit" onClick={submit} value="Submit"></input>
      </fieldset>
      <ToastContainer />


    </>
  )
}
