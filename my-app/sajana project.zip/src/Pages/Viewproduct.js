import axios from 'axios'
import React, { useEffect, useState } from 'react'

export default function Viewproduct() {
    const [view,setView]=useState([])
    console.log(view)
    
  useEffect(()=>{
    axios.get("http://localhost:5000/product/productdetails").then((response)=>{
      // console.log(response.data.trainer_details)
      setView(response.data.product_details)
    })
    
  },[])
  return (
    <>
  





  <div >





<div class="container" >

    <div class="row">


        {view.map((item) => (

        <div class="col-sm-4" style={{color:'white'}}>
            
            <img src="/Images/diet.jpg" alt="" height="400px" width="350px" />
            <br /><br />
            <h6>{item.Productname}</h6>
            <p>{item.Description}</p>
            <h5>{item.Price}</h5>
        </div>

        ))}

    </div>
</div>


</div>

</>
)
}

