
import { useState } from 'react'
import '../css/Login.css'
import axios from 'axios'

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {  useNavigate } from 'react-router-dom';



export default function Login() {



    
    const [input, setInput] = useState({ //store all data
        Username: '', //default set as 
        Password: ''
    })

    const inputChange = (event) => { // data entered->input 
        const { name, value } = event.target
        setInput({ ...input, [name]: value })
    }

    const [formError, setFormError] = useState({})
    console.log(formError); //error message view aakan


    const validate = (values) => {

        var error = {}

        if (!values.Username) {
            error.Username = "Enter Username" //Username ilenkil
        }
        if (!values.Password) {
            error.Password = "Enter Password" //Password illenkil
        }


        return error

    }
    const navigate = useNavigate() //page redirection

    const submit = (e) => {
        e.preventDefault() //page reload aavathe irikan
        setFormError(validate(input))
        if (Object.keys(formError).length == 0) { //errors undo ille check aakan,ethra length undennum


            // to connect react and node
            axios.post("http://localhost:5000/log", input).then((response) => {

                console.log(response.data.details);
                
                localStorage.setItem("UserName",response.data.details.Username)
                localStorage.setItem("Role",response.data.details.Role)
                localStorage.setItem("Id",response.data.details._id)
                
                if(response.data.details.Role=='2'){
                    navigate('/Login')
                }
                else if (response.data.details.Role=='3') {
                    navigate('/trainerhome')
                }
                else{
                    navigate('/')
                }
                
                
               




            }).catch((error) => {

                console.log(error);
                toast.error(error.response.data.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "colored",
                });
            })








        }

    }

    console.log(input);

    // 

    const [registerinput, setRegisterinput] = useState({
        Username: '',
        Name: '',
        Password: '',
        Email: '',
        Phone: '',
        Gender: '',
        Address: '',
    })
    const registerinputChange = (event) => {
        const { name, value } = event.target
        setRegisterinput({ ...registerinput, [name]: value })
    }



    const [registerformError, setRegisterformError] = useState({})
    console.log(registerformError);
    const regvalidates = (regvalues) => {

        var regerrors = {}

        if (!regvalues.Username) {
            regerrors.Username = "Enter Username"
        }
        if (!regvalues.Password) {
            regerrors.Password = "Enter Password"
        }
        if (!regvalues.Email) {
            regerrors.Email = "Enter Email"
        }
        if (!regvalues.Phone) {
            regerrors.Phone = "Enter Phone"
        }
        if (!regvalues.Name) {
            regerrors.Name = "Enter Name"
        }

        if (!regvalues.Address) {
            regerrors.Address = "Enter Address"
        }
        if (!regvalues.Gender) {
            regerrors.Gender = "Enter Gender"
        }

        return regerrors

    }


    const registersubmit = (e) => {
        e.preventDefault()
        setRegisterformError(regvalidates(registerinput))
        if (Object.keys(registerformError).length == 0) {
            // console.log(" Registration completed ");




            // to connect react and node
            axios.post("http://localhost:5000/", registerinput).then((response) => {

                console.log(response.data.message);



                toast.success(response.data.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "colored",
                });


            }).catch((error) => {

                console.log(error);
                toast.error(error.response.data.message, {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "colored",
                });
            })
        }
    }


    console.log(registerinput);


    return (
        <div id="bodyy">
            <div class="container" id="container">
                <input type="checkbox" id="flip"></input>
                <div class="cover">
                    <div class="front">
                        <img src="../Images/log.jpg" width={"500px"} alt=""></img>
                        <div class="text">
                            <span class="text-1">The body achieves <br /> what the mind believes.</span>
                            <span class="text-2">Let's get connected</span>
                        </div>
                    </div>
                    <div class="back">
                        {/* <img class="backImg" src="../IMAGES/heart.jpg" alt="">   */}
                        <div class="text">
                            <span class="text-1"><br /> </span>
                            <span class="text-2"></span>
                        </div>
                    </div>
                </div>
                <div class="forms">
                    <div class="form-content">
                        <div class="login-form">
                            <div class="title">Login</div>
                            <form action="#">
                                <div class="input-boxes">
                                    <div class="input-box">
                                        <i class="fas fa-user"></i>
                                        <input type="text" name='Username' onClick={() => { setFormError({ ...formError, Username: "" }) }} onChange={inputChange} placeholder="Enter your name" required></input>
                                        <span style={{ color: formError.Username ? "red" : "" }}>{formError.Username}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-lock"></i>
                                        <input type="Password" name='Password' onClick={() => { setFormError({ ...formError, Password: "" }) }} onChange={inputChange} placeholder="Enter your Password" required></input>
                                        <span style={{ color: formError.Password ? "red" : "" }}>{formError.Password}</span>
                                    </div>
                                    <div class="text"><a href="#">Forgot Password?</a></div>
                                    <div class="button input-box">
                                        <input onClick={submit} type="submit" value="Submit"></input>
                                    </div>
                                    <div class="text sign-up-text">Don't have an account? <label for="flip">Register now</label>
                                    </div>
                                </div>
                            </form>
                            <ToastContainer />
                        </div>
                        <div class="signup-form">
                            <div class="title">Registration</div>
                            <form action="#">
                                <div class="input-boxes">
                                    <div class="input-box">
                                        <i class="fas fa-user"></i>
                                        <input type="text" name='Username' onClick={() => { setRegisterformError({ ...registerformError, Username: "" }) }} onChange={registerinputChange} placeholder="User Name" required></input>
                                        <span style={{ color: registerformError.Username ? "red" : "" }}>{registerformError.Username}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-user"></i>
                                        <input type="text" name='Name' onClick={() => { setRegisterformError({ ...registerformError, Name: "" }) }} onChange={registerinputChange} placeholder=" Name" required></input>
                                        <span style={{ color: registerformError.Name ? "red" : "" }}>{registerformError.Name}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-envelope"></i>
                                        <input type="text" name='Email' onClick={() => { setRegisterformError({ ...registerformError, Email: "" }) }} onChange={registerinputChange} placeholder="Email" required></input>
                                        <span style={{ color: registerformError.Email ? "red" : "" }}>{registerformError.Email}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-lock"></i>
                                        <input type="Password" name='Password' onClick={() => { setRegisterformError({ ...registerformError, Password: "" }) }} onChange={registerinputChange} placeholder="Password" required></input>
                                        <span style={{ color: registerformError.Password ? "red" : "" }}>{registerformError.Password}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-phone"></i>
                                        <input type="Phone" name='Phone' onClick={() => { setRegisterformError({ ...registerformError, Phone: "" }) }} onChange={registerinputChange} placeholder="Phone" required></input>
                                        <span style={{ color: registerformError.Phone ? "red" : "" }}>{registerformError.Phone}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-address-book"></i>
                                        <input type="Address" name='Address' onClick={() => { setRegisterformError({ ...registerformError, Address: "" }) }} onChange={registerinputChange} placeholder="Address" required></input>
                                        <span style={{ color: registerformError.Address ? "red" : "" }}>{registerformError.Address}</span>
                                    </div>
                                    <div class="input-box">
                                        <i class="fas fa-user"></i>
                                        <input type="Gender" name='Gender' onClick={() => { setRegisterformError({ ...registerformError, Gender: "" }) }} onChange={registerinputChange} placeholder="Gender" required></input>
                                        <span style={{ color: registerformError.Gender ? "red" : "" }}>{registerformError.Gender}</span>
                                    </div>
                                    <div class="button input-box">
                                        <input type="submit" value="submit" onClick={registersubmit}  ></input>
                                    </div>
                                    <div class="text sign-up-text">Already have an account? <label for="flip">Login now</label>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}



