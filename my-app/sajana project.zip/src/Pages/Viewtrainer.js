import axios from 'axios';
import React, { useEffect, useState } from 'react'

export default function Viewtrainer() {


     //to view details 
  const [view,setView]=useState([])
    console.log(view)
    
  useEffect(()=>{
    axios.get("http://localhost:5000/trainer/trainerdetails").then((response)=>{
      // console.log(response.data.trainer_details)
      setView(response.data.trainer_details)
    })
    
  },[]) //dependencies array 




  return (
    <>
      
         
      <div >





                <div class="container" >

                    <div class="row">


                        {view.map((item) => (

                        <div class="col-sm-4" style={{color:'white'}}>
                            
                            <img src="/Images/tra.jfif" alt="" height="400px" width="350px" />
                            <br /><br />
                            <h6>{item.TrainerName}</h6>
                            <p>{item.Email}</p>
                        </div>

                        ))}

                    </div>
                </div>
           
       
</div>
    
    </>
  )
}
